package com.kodilla.testing.shape;

public class Square implements IShape
{
    private double side = 0;

    public Square(double side) {
        this.side = side;
    }

    @Override
    public String getShapeName() {
        return "square";
    }

    @Override
    public double getField() {
        return Math.pow(side,2);
    }
}
