package com.kodilla.testing.shape;

public interface IShape {
     String getShapeName();
     double getField();
}
