package com.kodilla.testing.shape;

public class Triangle implements IShape{

    private double height = 0;
    private double base = 0;

    public Triangle(double height, double base) {
        this.height = height;
        this.base = base;
    }

    @Override
    public String getShapeName() {
        return "triangle";
    }

    @Override
    public double getField() {
        return 0.5*height*base;
    }
}
