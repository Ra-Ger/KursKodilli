package com.kodilla.testing.shape;

import com.kodilla.testing.forum.ForumPost;
import com.kodilla.testing.forum.ForumUser;
import org.junit.jupiter.api.*;
import java.util.*;

@DisplayName("TDD: Forum Test Suite")
public class ShapeCollectorTestSuite {

    private static int testCounter = 0;

    @BeforeAll
    public static void beforeAllTests() {
        System.out.println("This is the beginning of tests.");
    }

    @AfterAll
    public static void afterAllTests() {
        System.out.println("All tests are finished.");
    }

    @BeforeEach
    public void beforeEveryTest() {
        testCounter++;
        System.out.println("Preparing to execute test #" + testCounter);
    }

    @Nested
    @DisplayName("Tests for removing Shape")
    class TestRemoveShape {
        @Test
        void testRemoveShape() {
            //Given
            List<IShape> shapesList = List.of(new Triangle(4, 2), new Square(5), new Circle(10));
            ShapeCollector SC = new ShapeCollector(shapesList);
            //When
            SC.removeFigure(shapesList.get(2));

            //Then
            Assertions.assertEquals("triangle field: 4, square field: 25, ", SC.showFigures()); // Figure_name field: [count],_
        }
    }

    @Nested
    @DisplayName("Tests for getting Shape")
    class TestGetShape {

    }

    @Nested
    @DisplayName("Tests for displaying shapes")
    class TestDisplayShape {

    }

    @Nested
    @DisplayName("Tests for adding Shape")
    class TestAddShape {

    }

}
